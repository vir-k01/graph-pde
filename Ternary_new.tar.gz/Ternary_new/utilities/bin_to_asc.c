#include<stdio.h>
#include<math.h>
#include<fftw3.h>
#define nx 1024
#define ny 1024

int
main (void)
{
 FILE *fpread;
 char fr[100];
 double comp_a[nx][ny], sum = 0.0, mean;
 double total_b, total_c;
 int initcount;
 fftw_complex *comp_b, *comp_c;

 comp_b = fftw_malloc (nx * ny * sizeof (fftw_complex));
 comp_c = fftw_malloc (nx * ny * sizeof (fftw_complex));

 int i, j;

 scanf ("%d", &initcount);
 sprintf (fr, "comp.%06d", initcount);
 printf ("%s\n", fr);
 fpread = fopen (fr, "r");

 fread (&comp_b[0][0], sizeof (double), 2 * nx * ny, fpread);
 fread (&comp_c[0][0], sizeof (double), 2 * nx * ny, fpread);
 fclose (fpread);
 total_b = 0.0;
 total_c = 0.0;
 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   comp_a[i][j] = 1.0 - comp_b[j + i * ny][0] - comp_c[j + i * ny][0];
   if(i==j)
   printf (" %d\t%lf\t%lf\t%lf\n ", i,comp_a[i][j], comp_b[j + ny * i][0], 
                                                  comp_c[j + ny * i][0]); 
    total_b += comp_b[j + i * ny][0];
    total_c += comp_c[j + i * ny][0];
  }
 }
 total_b = total_b/(double) (nx * ny); 
 total_c = total_c/(double) (nx * ny); 
 printf("total_b = %le\t total_c = %le\n", total_b, total_c);
 fftw_free (comp_b);
 fftw_free (comp_c);

}
