#include<stdio.h>
#include<math.h>
#define A 1.0
#define B 6.0
#define PI M_PI
#define kb_T 0.005

int
main (void)
{
 int i, tmp1, tmp2;
 int n_ppt, n_ppt_new, total_ppt;
 double mu_A (double cb, double cc);
 double mu_B (double cb, double cc);
 double mu_C (double cb, double cc);
 double cb_matrix, cc_matrix;
 double cb_ppt, cc_ppt, ca_ppt;
 double G1, G2;
 double t1, t2, t3, t4, t5, t6, t7;
 double del_GV;
 double G_star, r_star, G_star_std;
 double sigma = 0.42;
 double prob_dist;
 FILE *fpt;
 char fn1[150];

 fputs ("Enter the initial composition\n", stdout);
 scanf ("%lf", &cb_matrix);
 scanf ("%lf", &cc_matrix);
 printf ("cb_matrix= %lf cc_matrix = %lf\n", cb_matrix, cc_matrix);
 fputs ("Enter the starting no. of particles\n", stdout);
 scanf ("%d", &n_ppt);
 tmp1 = ceil(100 * cb_matrix);
 tmp2 = ceil(100 * cc_matrix);
 sprintf (fn1, "Nucleate_compB%02d_compC%02d", tmp1, tmp2);
 printf ("cb_matrix= %d cc_matrix = %d\n", tmp1, tmp2);
 
 fpt = fopen (fn1, "w");
 
 t1 = mu_A (cb_matrix, cc_matrix);
 t2 = mu_B (cb_matrix, cc_matrix);
 t3 = mu_C (cb_matrix, cc_matrix);
 total_ppt = 0;
  cb_ppt = 0.0;
  for (i=0;i<=100;i++){ 
  cc_ppt = fabs(1.0 - cb_ppt);
  G1 = (1.0 - cb_ppt - cc_ppt) * t1 + cb_ppt * t2 + cc_ppt * t3;
  t4 = mu_A (cb_ppt, cc_ppt);
  t5 = mu_B (cb_ppt, cc_ppt);
  t6 = mu_C (cb_ppt, cc_ppt);
  ca_ppt = (1.0 - cb_ppt - cc_ppt);
  t7 = A * (cb_ppt * cb_ppt * cc_ppt * cc_ppt +
            ca_ppt * ca_ppt * cb_ppt * cb_ppt +
            cc_ppt * cc_ppt * ca_ppt * ca_ppt)
   + B * (cb_ppt * cb_ppt * cc_ppt * cc_ppt * ca_ppt * ca_ppt);
  G2 = (1.0 - cb_ppt - cc_ppt) * t4 + cb_ppt * t5 + cc_ppt * t6;
  del_GV = (G1 - G2);
  G_star = (PI * sigma * sigma) / (del_GV);
  r_star = (sigma) / del_GV;

  if (cb_ppt == 0.0) {
   G_star_std = G_star;
  }
  prob_dist = exp ((G_star_std - G_star) / (kb_T));
  n_ppt_new = (int) (n_ppt * exp ((G_star_std - G_star) / (kb_T)));
  printf ("%lf\t %lf\t %lf\t %lf\t %d\n", cb_ppt, cc_ppt, G_star,
          r_star, n_ppt_new);
  fwrite (&cb_ppt, sizeof(double), (size_t) 1, fpt);
  fwrite (&cc_ppt, sizeof(double), (size_t) 1, fpt);
  fwrite (&r_star, sizeof(double), (size_t) 1, fpt);
  fwrite (&n_ppt_new, sizeof(int), (size_t) 1, fpt);
  total_ppt = total_ppt + n_ppt_new;
  cb_ppt = cb_ppt + 0.01;
 }

 printf ("total precipitates = %d\n", total_ppt);
 fclose (fpt);
}

double
mu_A (double cb, double cc)
{
 double ca;
 double casq;
 double cbsq;
 double ccsq;
 double P;
 double Q;
 double free;
 double result;

 ca = 1.0 - cb - cc;
 casq = ca * ca;
 cbsq = cb * cb;
 ccsq = cc * cc;
 free = A * (cbsq * ccsq + casq * cbsq + ccsq * casq)
  + B * (cbsq * ccsq * casq);
 P =
  A * (-2.0 * ca * cbsq + 2.0 * casq * cb - 2.0 * ca * ccsq +
       2.0 * cb * ccsq) + 2.0 * B * cb * ccsq * casq -
  2.0 * B * cbsq * ccsq * ca;

 Q =
  A * (-2.0 * ca * cbsq - 2.0 * ca * ccsq + 2.0 * casq * cc +
       2.0 * cbsq * cc) + 2.0 * B * cbsq * cc * casq -
  2.0 * B * cbsq * ccsq * ca;
 result = free - cb * P - cc * Q;

 return result;
}

double
mu_B (double cb, double cc)
{
 double ca;
 double casq;
 double cbsq;
 double ccsq;
 double P;
 double Q;
 double free;
 double result;

 ca = 1.0 - cb - cc;
 casq = ca * ca;
 cbsq = cb * cb;
 ccsq = cc * cc;
 free = A * (cbsq * ccsq + casq * cbsq + ccsq * casq)
  + B * (cbsq * ccsq * casq);
 P =
  A * (-2.0 * ca * cbsq + 2.0 * casq * cb - 2.0 * ca * ccsq +
       2.0 * cb * ccsq) + 2.0 * B * cb * ccsq * casq -
  2.0 * B * cbsq * ccsq * ca;

 Q =
  A * (-2.0 * ca * cbsq - 2.0 * ca * ccsq + 2.0 * casq * cc +
       2.0 * cbsq * cc) + 2.0 * B * cbsq * cc * casq -
  2.0 * B * cbsq * ccsq * ca;
 result = free + (1.0 - cb) * P - cc * Q;
 return result;
}

double
mu_C (double cb, double cc)
{
 double ca;
 double casq;
 double cbsq;
 double ccsq;
 double P;
 double Q;
 double free;
 double result;

 ca = 1.0 - cb - cc;
 casq = ca * ca;
 cbsq = cb * cb;
 ccsq = cc * cc;
 free = A * (cbsq * ccsq + casq * cbsq + ccsq * casq)
  + B * (cbsq * ccsq * casq);
 P =
  A * (-2.0 * ca * cbsq + 2.0 * casq * cb - 2.0 * ca * ccsq +
       2.0 * cb * ccsq) + 2.0 * B * cb * ccsq * casq -
  2.0 * B * cbsq * ccsq * ca;

 Q =
  A * (-2.0 * ca * cbsq - 2.0 * ca * ccsq + 2.0 * casq * cc +
       2.0 * cbsq * cc) + 2.0 * B * cbsq * cc * casq -
  2.0 * B * cbsq * ccsq * ca;
 result = free - cb * P + (1.0 - cc) * Q;
 return result;
}
