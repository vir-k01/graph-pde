#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<float.h>
#include<fftw3.h>
#define nx 1024
#define ny 1024
#define Re 0
#define Im 1

int main(void)
{
  FILE *fpt2;
  fftw_complex *comp_b, *comp_c;
  double cb_matrix, cc_matrix;
  char fn2[100];
  int o_sites, i, j, rad;
  int nx_half, ny_half;
  double compb, compc,total_b,total_c;
  int occupancy[nx][ny];


  comp_b = fftw_malloc(sizeof(fftw_complex) * nx * ny);
  comp_c = fftw_malloc(sizeof(fftw_complex) * nx * ny);
  for (i = 0; i < nx; i++) {
    for (j = 0; j < ny; j++) {
      comp_b[j + i * ny][Re] = 0.0;
      comp_c[j + i * ny][Re] = 0.0;
      comp_b[j + i * ny][Im] = 0.0;
      comp_c[j + i * ny][Im] = 0.0;
    }
  }
  fputs("Enter the initial composition\n", stdout);
  scanf("%lf", &cb_matrix);
  scanf("%lf", &cc_matrix);
  fputs("Enter the radius\n", stdout);
  scanf("%d", &rad);
  sprintf(fn2, "profile_cb%02d_cc%02d", (int) (100 * cb_matrix),
	  (int) (100 * cc_matrix)); 
  nx_half = nx/2;
  ny_half = ny/2;
  compb = 0.0;
  compc = 1.0;

    for (i = 0; i < nx; i++) {
      for (j = 0; j < ny; j++) {
      if (((i-nx_half) * (i-nx_half) +  (j-ny_half) * (j-ny_half)) 
           <= (rad * rad)){
	    comp_b[j + i * ny][Re] = compb;
	    comp_c[j + i * ny][Re] = compc;
	  }
      }}
  total_b = 0.0;
  total_c = 0.0;
  for (i = 0; i < nx; i++) {
    for (j = 0; j < ny; j++) {
      total_b = total_b + comp_b[j + i * ny][Re];
      total_c = total_c + comp_c[j + i * ny][Re];
    }
  }
  total_b = total_b / (double) (nx * ny);
  total_c = total_c / (double) (nx * ny);
  printf("%le\t %le\n", total_b, total_c);
  o_sites = 1;
  for (i = 0; i < nx; i++) {
    for (j = 0; j < ny; j++) {
      if ((comp_b[j + i * ny][Re] < DBL_EPSILON) &&
       (comp_c[j + i * ny][Re] < DBL_EPSILON)){
    o_sites = o_sites + 1;
    }
    }
  }
  for (i = 0; i < nx; i++) {
    for (j = 0; j < ny; j++) {
      if ((comp_b[j + i * ny][Re] < DBL_EPSILON) &&
       (comp_c[j + i * ny][Re] < DBL_EPSILON)){
	comp_b[j + i * ny][Re] = ((cb_matrix - total_b)*(nx*ny))/(o_sites);
	comp_c[j + i * ny][Re] = ((cc_matrix - total_c)*(nx*ny))/(o_sites);
    }
    }
  }
  printf("%le\t %le\n", ((cb_matrix - total_b)*(nx*ny))/(o_sites),  ((cc_matrix - total_c)*(nx*ny))/(o_sites));

  total_b = 0.0;
  total_c = 0.0;
  for (i = 0; i < nx; i++) {
    for (j = 0; j < ny; j++) {
      total_b = total_b + comp_b[j + i * ny][Re];
      total_c = total_c + comp_c[j + i * ny][Re];
    }
  }
  total_b = total_b / (double) (nx * ny);
  total_c = total_c / (double) (nx * ny);
  printf("%le\t %le\n", total_b, total_c);
  fpt2 = fopen(fn2, "w");
  
  fwrite(&comp_b[0][0], sizeof(double), 2 * nx * ny, fpt2);
  fwrite(&comp_c[0][0], sizeof(double), 2 * nx * ny, fpt2);
  fclose(fpt2);
  fftw_free(comp_b);
  fftw_free(comp_c);
}
