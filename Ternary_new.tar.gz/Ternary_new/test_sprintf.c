#include<stdio.h>
#include<math.h>

int main(void)
{
	int t1, t2;
    t1 = (int) round(15.01);
    t2 = (int) round(14.9);
/*	int term1, term2;

 	printf("Enter the values of t1 and t2\n");
    scanf("%lf%lf",&t1,&t2);
	printf("t1=%lf\t t2=%lf\n", t1,t2);
	
	sprintf(fn1, "Test_t%02d_t%02d",(int) ceil(100*t1), (int) ceil(100*t2));

	term1 = (int) ceil(100 * t1);
	term2 = (int) ceil(100 * t2);
	printf("term1=%d\t term2=%d\n", term1,term2);

	sprintf(fn2, "Test_t%02d_t%02d",term1, term2);*/
	
	printf("%d\t %d\n", t1, t2);

	return(0);

}
