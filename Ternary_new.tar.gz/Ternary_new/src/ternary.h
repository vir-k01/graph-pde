#include<stdio.h>
#include<stddef.h>
#include<stdlib.h>
#include<math.h>
#include<gsl/gsl_rng.h>
#include<gsl/gsl_randist.h>
#include<fftw3.h>
#include"nrutil.h"
#define PI M_PI
#define Tolerance 1.0e-10
#define COMPERR 1.0e-6
#define A 1.0
#define B 6.0
#define Re 0
#define Im 1 

const gsl_rng_type *T;

unsigned fftw_flag;

long SEED;

fftw_complex *comp_b, *comp_c, *dfdc_b, *dfdc_c;

fftw_plan p_up, p_dn;


int num_steps, count;

int initcount, flag;

int noise_flag;

double alloycomp_b, alloycomp_c, noise_level; 

double sustained_noise_level;

double del_x, del_y, del_t;

double sim_time, total_time;

double total_A, total_B, err1, err2;

double sigma;

int nx, ny, nx_half, ny_half;

int n_cout;

double mobil_bb, mobil_cc, mobil_bc, kappa_bb, kappa_cc, kappa_bc;

double ka, kb, kc, ma, mb, mc;

double aa, bb, dd, pp, qq, ll, mm;

double one_by_nxny;

FILE *fpout;
