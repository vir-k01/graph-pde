#include"ternary.h"
void
Init_Conf_Rand ()
{

 gsl_rng *r;
 double **random_numA, **random_numB, **comp_a;
 double sum1 = 0.0, mean1;
 double sum2 = 0.0, mean2;
 int i, j;


 gsl_rng_env_setup ();
 T = gsl_rng_taus2;
 r = gsl_rng_alloc (T);
 random_numA = dmatrix (0, nx, 0, ny);
 random_numB = dmatrix (0, nx, 0, ny);
 comp_a = dmatrix (0, nx, 0, ny);

 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   comp_b[j + i * ny][Re] = alloycomp_b;
   comp_b[j + i * ny][Im] = 0.0;
   comp_c[j + i * ny][Re] = alloycomp_c;
   comp_c[j + i * ny][Im] = 0.0;
  }
 }
 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   random_numA[i][j] = gsl_rng_uniform(r);
   random_numA[i][j] = (2.0 * random_numA[i][j]) - 1.0;
   random_numA[i][j] = random_numA[i][j] * noise_level * alloycomp_b;
   sum1 += random_numA[i][j];
  }
 }
 mean1 = sum1 / (nx * ny);
 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   random_numB[i][j] = gsl_rng_uniform(r);
   random_numB[i][j] = (2.0 * random_numB[i][j]) - 1.0;
   random_numB[i][j] = random_numB[i][j] * noise_level * alloycomp_c;
   sum2 += random_numB[i][j];
  }
 }
 mean2 = sum2 / (nx * ny);


 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   random_numA[i][j] = mean1 - random_numA[i][j];
   random_numB[i][j] = mean2 - random_numB[i][j];
   comp_b[j + i * ny][Re] = comp_b[j + i * ny][Re] + random_numA[i][j];
   comp_c[j + i * ny][Re] = comp_c[j + i * ny][Re] + random_numB[i][j];
   comp_a[i][j] = 1.0 - comp_b[j + i * ny][Re] - comp_c[j + i * ny][Re];
  }
 }
 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   dfdc_b[j + i * ny][Re] = comp_b[j + i * ny][Re];
   dfdc_c[j + i * ny][Re] = comp_c[j + i * ny][Re];
   dfdc_b[j + i * ny][Im] = comp_b[j + i * ny][Im];
   dfdc_c[j + i * ny][Im] = comp_c[j + i * ny][Im];
  }
 }
 free_dmatrix (random_numA, 0, nx, 0, ny);
 free_dmatrix (random_numB, 0, nx, 0, ny);
 free_dmatrix (comp_a, 0, nx, 0, ny);
 gsl_rng_free (r);
}

void
Init_Conf_File ()
{
 FILE *fpread;
 char fr[100];
 int i, j;
 gsl_rng *r;
 double **random_numA, **random_numB;
 double sum1 = 0.0, mean1;
 double sum2 = 0.0, mean2;

 gsl_rng_env_setup ();
 T = gsl_rng_taus2;
 r = gsl_rng_alloc (T);
 random_numA = dmatrix (0, nx, 0, ny);
 random_numB = dmatrix (0, nx, 0, ny);
 
 sprintf (fr, "comp.%06d", initcount);

 fpread = fopen (fr, "r");
 fread (&comp_b[0][0], sizeof(double), 2 * nx * ny, fpread);
 fread (&comp_c[0][0], sizeof(double), 2 * nx * ny, fpread);
 fclose (fpread);

for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   random_numA[i][j] = gsl_rng_uniform(r);
   random_numA[i][j] = (2.0 * random_numA[i][j]) - 1.0;
   random_numA[i][j] = random_numA[i][j] * noise_level;
   sum1 += random_numA[i][j];
  }
 }
 mean1 = sum1 / (nx * ny);
 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   random_numB[i][j] = gsl_rng_uniform(r);
   random_numB[i][j] = (2.0 * random_numB[i][j]) - 1.0;
   random_numB[i][j] = random_numB[i][j] * noise_level;
   sum2 += random_numB[i][j];
  }
 }
 mean2 = sum2 / (nx * ny);


 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   random_numA[i][j] = mean1 - random_numA[i][j];
   random_numB[i][j] = mean2 - random_numB[i][j];
   comp_b[j + i * ny][Re] = comp_b[j + i * ny][Re] + random_numA[i][j];
   comp_c[j + i * ny][Re] = comp_c[j + i * ny][Re] + random_numB[i][j];
  }
 }



 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   dfdc_b[j + i * ny][Re] = comp_b[j + i * ny][Re];
   dfdc_b[j + i * ny][Im] = comp_b[j + i * ny][Im];
   dfdc_c[j + i * ny][Re] = comp_c[j + i * ny][Re];
   dfdc_c[j + i * ny][Im] = comp_c[j + i * ny][Im];
  }
 }

free_dmatrix (random_numA, 0, nx, 0, ny);
free_dmatrix (random_numB, 0, nx, 0, ny);
gsl_rng_free (r);
}
