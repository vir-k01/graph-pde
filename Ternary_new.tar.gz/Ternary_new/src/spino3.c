#include"ternary.h"
int
main (void)
{
 void Get_Input_Spino (char *fnin, char *fnout);
 void Init_Conf_Rand ();
 void Init_Conf_File ();
 void Evolve ();
 char finput[15] = "tern1ary";
 char fnin[15], fnout[15];
 FILE *fp;
 unsigned FLAG;

 if (!(fp = fopen (finput, "r"))) {
  printf ("File:%s could not be opened\n", finput);
  exit (EXIT_FAILURE);
 }
  fscanf (fp, "%s", fnin);
  fscanf (fp, "%s", fnout);
 if (!(fpout = fopen (fnout, "w"))) {
  printf ("File:%s could not be opened\n", fnout);
  exit (EXIT_FAILURE);
 }
  fclose (fp);

 Get_Input_Spino (fnin, fnout);

 comp_b = fftw_malloc (sizeof (fftw_complex) * nx * ny);
 comp_c = fftw_malloc (sizeof (fftw_complex) * nx * ny);
 dfdc_b = fftw_malloc (sizeof (fftw_complex) * nx * ny);
 dfdc_c = fftw_malloc (sizeof (fftw_complex) * nx * ny);


 nx_half = nx / 2;

 ny_half = ny / 2;

 one_by_nxny = 1.0 / (double) (nx * ny);

 mobil_bb = mb;
 mobil_cc = mc;
 mobil_bc = ma;

//      printf("%lf\t%lf\t%lf\n",mobil_bb,mobil_cc,mobil_bc);

 kappa_bb = kb + ka;
 kappa_cc = kc + ka;
 kappa_bc = ka;

 aa = -1.0 * (mobil_bb);
 bb = -1.0 * (mobil_bc);
 dd = -1.0 * (mobil_cc);

 ll = -2.0 * (mobil_bb * kappa_bb + mobil_bc * kappa_bc);
 mm = -2.0 * (mobil_bc * kappa_cc + mobil_bb * kappa_bc);
 pp = -2.0 * (mobil_cc * kappa_cc + mobil_bc * kappa_bc);
 qq = -2.0 * (mobil_cc * kappa_bc + mobil_bc * kappa_bb);

 FLAG = FFTW_ESTIMATE;
 
 if(fftw_flag == 1)
 FLAG = FFTW_MEASURE;
 
 if(fftw_flag == 2)
 FLAG = FFTW_PATIENT;
 
 if(fftw_flag == 3)
 FLAG = FFTW_EXHAUSTIVE;
 
 p_up = fftw_plan_dft_2d (nx, ny, comp_b, comp_b, FFTW_FORWARD,
                          FLAG);
 p_dn = fftw_plan_dft_2d (nx, ny, comp_b, comp_b, FFTW_BACKWARD,
                          FLAG);

 if (flag == 0) {
  Init_Conf_Rand ();
 }
 else
  Init_Conf_File ();

 sim_time = 0.0;
 count = 0;
 Evolve ();
 fclose (fpout);
 fftw_destroy_plan (p_up);
 fftw_destroy_plan (p_dn);
 fftw_free (comp_b);
 fftw_free (comp_c);
 fftw_free (dfdc_b);
 fftw_free (dfdc_c);
 return (0);
}
