#include"ternary.h"
void
Output_Conf ()
{
 FILE *fpt1;

 int i, j;

 char fn1[100];
 double **comp_a;

 comp_a = dmatrix (0, nx, 0, ny);
 for (i = 0; i < nx; i++) {
  for (j = 0; j < ny; j++) {
   comp_a[i][j] = 1.0 - dfdc_b[j + i * ny][Re] - dfdc_c[j + i * ny][Re];
  }
 }

 sprintf (fn1, "comp.%06d", count + initcount);

 fpt1 = fopen (fn1, "w");
 fwrite (&dfdc_b[0][0], sizeof(double), 2 * nx * ny, fpt1);
 fwrite (&dfdc_c[0][0], sizeof(double), 2 * nx * ny, fpt1);
 fclose (fpt1);
 free_dmatrix (comp_a, 0, nx, 0, ny);
}
