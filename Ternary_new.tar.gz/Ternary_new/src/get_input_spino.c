#include"ternary.h"
void
Get_Input_Spino (char *fnin, char *fnout)
{
 FILE *fpin, *fpcout;
 char  param[100];

 if (!(fpcout = fopen (fnout, "w"))) {
  printf ("File:%s could not be opened \n", fnout);
  exit (1);
 }
 fprintf (fpcout, "The name of this file is : %s \n", fnout);
 fprintf (fpcout, "Input is from            : %s \n", fnin);

 if (!(fpin = fopen (fnin, "r"))) {
  printf ("File: %s could not be opened \n", fnin);
  exit (1);
 }

 fscanf (fpin, "%s%d", param,&nx);
 fscanf (fpin, "%s%d", param,&ny);
 fscanf (fpin, "%s%lf",param,&del_x);
 fscanf (fpin, "%s%lf",param,&del_y);
 fscanf (fpin, "%s%lf",param,&del_t);
 fscanf (fpin, "%s%lf",param,&noise_level);
 fscanf (fpin, "%s%ld",param,&SEED);
 fscanf (fpin, "%s%d", param,&num_steps);
 fscanf (fpin, "%s%lf",param,&alloycomp_b);
 fscanf (fpin, "%s%lf", param,&alloycomp_c);
 fscanf (fpin, "%s%lf %s%lf %s%lf", param,&kb, param,&kc, param,&ka);
 fscanf (fpin, "%s%lf %s%lf %s%lf", param,&mb, param,&mc, param,&ma);
 fscanf (fpin, "%s%d", param,&initcount);
 fscanf (fpin, "%s%d", param,&flag);
 fscanf (fpin, "%s%d", param,&fftw_flag);
 fclose (fpin);

 printf ("nx = %d\n", nx);
 printf ("ny = %d\n", ny);
 printf ("del_x = %lf\n", del_x);
 printf ("del_y = %lf\n", del_y);
 printf ("del_t = %lf\n", del_t);
 printf ("noise_level = %lf\n", noise_level);
 printf ("Seed = %ld\n", SEED);
 printf ("num_steps = %d\n", num_steps);
 printf ("composition_of_B = %lf\n", alloycomp_b);
 printf ("composition_of_C = %lf\n", alloycomp_c);
 printf ("KAP_B=%lf KAP_C=%lf KAP_A=%lf\n", kb, kc, ka);
 printf ("MBB=%lf MCC=%lf MBC=%lf\n", mb, mc, ma);
 printf ("Initial count = %d\t flag = %d\n", initcount, flag);
 printf ( "FFTW_FLAG=%d\n", fftw_flag);

 fprintf (fpcout, "nx = %d\n", nx);
 fprintf (fpcout, "ny = %d\n", ny);
 fprintf (fpcout, "del_x = %lf\n", del_x);
 fprintf (fpcout, "del_y = %lf\n", del_y);
 fprintf (fpcout, "del_t = %lf\n", del_t);
 fprintf (fpcout, "noise_level = %lf\n", noise_level);
 fprintf (fpcout, "Seed = %ld\n", SEED);
 fprintf (fpcout, "num_steps = %d\n", num_steps);
 fprintf (fpcout, "composition_of_B=%lf\t", alloycomp_b);
 fprintf (fpcout, "composition_of_C=%lf\n", alloycomp_c);
 fprintf (fpcout, "\n");
 fprintf (fpcout, "KAP_B=%lf  KAP_C=%lf  KAP_A=%lf\n", kb, kc, ka);
 fprintf (fpcout, "MBB=%lf    MCC=%lf     MBC=%lf\n", mb, mc, ma);
 fprintf (fpcout, "Initial count = %d\t flag = %d\n", initcount, flag);
 if (flag == 0)
  fprintf (fpcout, "Configuration is initialised by me\n");
 else
  fprintf (fpcout, "Configuration is read from file\n");
 fclose (fpcout);
}
