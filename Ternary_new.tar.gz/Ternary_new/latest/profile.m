clear all
r = input('Enter steps\n')

s1 = sprintf('comp_a.%06d', r)
s2 = sprintf('comp_b.%06d', r)
s3 = sprintf('comp_c.%06d', r)
s4 = sprintf('comp_a_%06d.eps', r)
s5 = sprintf('comp_b_%06d.eps', r)
s6 = sprintf('comp_c_%06d.eps', r)
load(s1)
load(s2)
load(s3)
imagesc(comp_a)
axis image 
colormap gray
colorbar
print('-deps',s4)
figure
imagesc(comp_b)
axis image 
colormap gray
colorbar
print('-deps',s5)
figure
imagesc(comp_c)
axis image 
colormap gray
colorbar
print('-deps',s6)


