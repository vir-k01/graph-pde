clear all
r = input('Enter steps\n')

s1 = sprintf('comp_a.%06d', r)
s2 = sprintf('comp_b.%06d', r)
s3 = sprintf('comp_c.%06d', r)
s4 = sprintf('comp_a_%06d_co.eps', r)
s5 = sprintf('comp_b_%06d_co.eps', r)
s6 = sprintf('comp_c_%06d_co.eps', r)
load(s1)
load(s2)
load(s3)
[c,h] = contour(comp_a);
clabel(c,h);
colormap gray
colorbar
print('-deps',s4)
figure
[c,h] = contour(comp_b);
clabel(c,h);
colormap gray
colorbar
print('-deps',s5)
figure
[c,h] = contour(comp_c);
clabel(c,h);
colormap gray
colorbar
print('-deps',s6)


